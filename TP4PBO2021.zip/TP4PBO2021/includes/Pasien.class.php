<?php  

class Pasien extends DB{
	//mengambil data
	function getPasien(){
		// Query mysql select data ke pasien
		$query = "SELECT * FROM pasien";

		// Mengeksekusi query
		return $this->execute($query);
	}

	function insertPasien(){
		$tnik = $_POST['tnik'];
		$tnama = $_POST['tnama'];
		$ttanggal = $_POST['ttanggal'];
		$tno = $_POST['tno'];
		$tpelayanan = $_POST['tpelayanan'];
		$tspesialis = $_POST['tspesialis'];
		$tjadwal = $_POST['tjadwal'];
		$tkeluhan = $_POST['tkeluhan'];

		// Query mysql insert data ke pasien
		$query = "INSERT INTO pasien(nik, nama, tgl_lahir, no_telp, pelayanan, spesialis, jadwal, keluhan, status)
			VALUES ('$tnik', '$tnama', '$ttanggal', '$tno',  '$tpelayanan', '$tspesialis', '$tjadwal', '$tkeluhan', 'Belum')";

		// Mengeksekusi query
		return $this->execute($query);
	}

	function deletePasien(){
		$id = $_GET['id_hapus'];
		// Query mysql delete data ke pasiem
		$query = "DELETE FROM pasien WHERE id = $id";

		// Mengeksekusi query
		return $this->execute($query);
	}

	function updatePasien(){
		$id = $_GET['id_status'];
		// Query mysql status data ke pasien
		$query = "UPDATE pasien SET status='Sudah' WHERE id = $id";

		// Mengeksekusi query
		return $this->execute($query);
	}
}
?>