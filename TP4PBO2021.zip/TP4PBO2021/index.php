<?php

include("conf.php");
include("includes/Template.class.php");
include("includes/DB.class.php");
include("includes/Pasien.class.php");

// Membuat objek dari kelas Pasien
$opasien = new Pasien($db_host, $db_user, $db_password, $db_name);
$opasien->open();

//Memanggil method insertPasien di kelas Pasien
if (isset($_POST['add'])){
	$opasien->insertPasien();

	header('Location: index.php');
}

// Memanggil method getPasien di kelas Pasien
$opasien->getPasien();

// Proses mengisi tabel dengan data
$data = null;
$no = 1;

while (list($id, $tnik, $tnama, $ttanggal, $tno, $tpelayanan, $tspesialis, $tjadwal, $tkeluhan, $tstatus) = $opasien->getResult()) {
	// Tampilan jika status pasien nya sudah diperiksa
	if($tstatus == "Sudah"){
		$data .= "<tr>
		<td>" . $no . "</td>
		<td>" . $tnik . "</td>
		<td>" . $tnama . "</td>
		<td>" . $ttanggal . "</td>
		<td>" . $tno . "</td>
		<td>" . $tpelayanan . "</td>
		<td>" . $tspesialis . "</td>
		<td>" . $tjadwal . "</td>
		<td>" . $tkeluhan . "</td>
		<td>" . $tstatus . "</td>
		<td>
		<button class='btn btn-danger'><a href='index.php?id_hapus=" . $id . "' style='color: white; font-weight: bold;'>Hapus</a></button>
		</td>
		</tr>";
		$no++;
	}

	// Tampilan jika status pasien nya belum diperiksa
	else{
		$data .= "<tr>
		<td>" . $no . "</td>
		<td>" . $tnik . "</td>
		<td>" . $tnama . "</td>
		<td>" . $ttanggal . "</td>
		<td>" . $tno . "</td>
		<td>" . $tpelayanan . "</td>
		<td>" . $tspesialis . "</td>
		<td>" . $tjadwal . "</td>
		<td>" . $tkeluhan . "</td>
		<td>" . $tstatus . "</td>
		<td>
		<button class='btn btn-danger'><a href='index.php?id_hapus=" . $id . "' style='color: white; font-weight: bold;'>Hapus</a></button>
		<button class='btn btn-success' ><a href='index.php?id_status=" . $id .  "' style='color: white; font-weight: bold;'>Selesai</a></button>
		</td>
		</tr>";
		$no++;
	}
}

if (isset($_GET['id_status'])) {
	$opasien->updatePasien();

	header('Location: index.php');
}

if (isset($_GET['id_hapus'])) {
	$opasien->deletePasien();

	header('Location: index.php');
}

// Menutup koneksi database
$opasien->close();

// Membaca template insert.html
$tpl = new Template("templates/insert.html");


// Mengganti kode Data_Tabel dengan data yang sudah diproses
$tpl->replace("DATA_TABEL", $data);

// Menampilkan ke layar
$tpl->write();
