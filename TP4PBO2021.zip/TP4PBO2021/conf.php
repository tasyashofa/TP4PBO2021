<?php
// Konfigurasi basis data

$db_host = "localhost"; // host 
$db_user = "root"; // user
$db_password = ""; // password
$db_name = "tp4dpbo2021"; // nama basis data

?>